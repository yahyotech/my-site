# Copyright (c) 2021, Frappe and Contributors
# See license.txt

# import frappe
import unittest


class TestCertification(unittest.TestCase):
	pass
