# Copyright (c) 2021, FOSS United and Contributors
# See license.txt
import unittest

import frappe

from lms.lms.doctype.invite_request.invite_request import (
	create_invite_request,
	update_invite,
)


class TestInviteRequest(unittest.TestCase):
	pass
