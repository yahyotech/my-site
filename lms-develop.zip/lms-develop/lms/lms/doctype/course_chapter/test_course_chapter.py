# Copyright (c) 2021, FOSS United and Contributors
# See license.txt

# import frappe
import unittest


class TestCourseChapter(unittest.TestCase):
	pass
