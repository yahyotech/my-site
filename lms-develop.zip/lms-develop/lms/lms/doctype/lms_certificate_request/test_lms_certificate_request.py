# Copyright (c) 2022, Frappe and Contributors
# See license.txt

# import frappe
from frappe.tests import UnitTestCase


class TestLMSCertificateRequest(UnitTestCase):
	pass
