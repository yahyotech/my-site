// Copyright (c) 2021, Frappe and contributors
// For license information, please see license.txt

frappe.ui.form.on("Function", {
	// refresh: function(frm) {
	// }
});
