frappe.pages["lms-home"].on_page_load = function (wrapper) {
	window.location.href = "/lms/courses";
};
