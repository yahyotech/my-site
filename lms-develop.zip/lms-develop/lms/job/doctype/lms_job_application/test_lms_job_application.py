# Copyright (c) 2024, Frappe and Contributors
# See license.txt

# import frappe
from frappe.tests import UnitTestCase


class TestLMSJobApplication(UnitTestCase):
	pass
